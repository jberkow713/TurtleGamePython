# TicTacToe AI
This is TicTacToe. 
The game file is TicTacWebsite.py.
All you need to do to play the game is to run the file.

You will immediately be prompted on the Turtle Screen.

You can play against the computer, or you can watch the computer play itself. If you want to play against the computer, you can choose any size grid between 3 and 19, odd number sides only. If you want to watch the computer play, you can choose any value between 3 and 20.

Next you will select the amount of spots needed for a win. This feature was implemented to make games more fun and more challenging. If you select a 3X3 or 5X5 grid, you must choose that many spots for a win, 3 or 5 respectively. Otherwise, the amount of spots selected for a win must be more than half the sides, and less than or equal to the amount of sides...so in the case of choosing an 11 by 11 grid, you can choose from 6 to 11 spots needed for a win.

There is another option, "Do you want to play to the end of the game?"
If you choose "yes" here, you will be able to play until all of the pieces are filled out.
If you choose "no", the game will be assessed after every computer and human choice, or computer vs computer choice, and once there is no longer able to be a winner, the game will end. Don't worry, it's accurate...

You can only move into open squares, and you must wait until the computer moves before you can move again. If you try and choose a square that has already been occupied, nothing will happen, and you must choose again. 

The computer is very difficult to beat. Good luck!